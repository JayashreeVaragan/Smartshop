export interface User{
    userId:string
    firstname:string
    lastname:string
    age:number
    gender:string
    contact:string
    password:string
    confirmPassword:string
    userType:string
    status:string
}