import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Product } from '../product/product';

import { HttpHeaders, HttpClient } from '@angular/common/http';
import { AuthServiceService } from '../auth-service.service';

@Injectable({
  providedIn: 'root'
})
export class ProductServiceService {

  constructor(private httpClient:HttpClient,private authservice:AuthServiceService) { }
  getAllProductTypes():Observable<Product[]>{
    let headers=new HttpHeaders();
 headers=headers.set('Authorization','Bearer '+this.authservice.getToken());
     return this.httpClient.get<Product[]>('http://localhost:8082/search-box',{headers});
}
}
