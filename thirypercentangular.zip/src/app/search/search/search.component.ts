import { Component, OnInit } from '@angular/core';
import { ProductServiceService } from 'src/app/services/product-service.service';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { Product } from 'src/app/product/product';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  searchKey:string;
  productList: Product[];
  filteredList:Product[];
 
 

 
  constructor(private productservice:ProductServiceService) { }

  ngOnInit() {
    this.productservice.getAllProductTypes().subscribe(
      data =>{this.productList=data; 
      this.filteredList=data
    console.log(this.filteredList)});
  }
  search(){
    this.filteredList=this.productList.filter(x=>x.productType.toLowerCase().indexOf(this.searchKey.toLowerCase())!=-1);
  }

}
